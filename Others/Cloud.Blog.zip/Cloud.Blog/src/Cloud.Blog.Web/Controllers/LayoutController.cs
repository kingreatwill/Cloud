namespace Cloud.Blog.Web.Controllers
{
    public class LayoutController : BlogControllerBase
    {

    }
}