﻿using Abp.Application.Services;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Cloud.Blog.Categories
{
    public interface ICategoryAppService : IApplicationService
    {
        Task<Category> Get(long id);

        Task<List<Category>> GetAll();
    }
}