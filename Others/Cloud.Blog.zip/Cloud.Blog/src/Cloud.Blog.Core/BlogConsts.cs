﻿namespace Cloud.Blog
{
    public class BlogConsts
    {
        public const string DbTablePrefix = "Blog";

        public const string LocalizationSourceName = "Blog";

        public const string ConnectionStringName = "Default";
    }
}