﻿namespace Abp.Samples.Blog.Posts
{
    public enum PostStatus : byte
    {
        Draft = 0,
        Published = 1
    }
}