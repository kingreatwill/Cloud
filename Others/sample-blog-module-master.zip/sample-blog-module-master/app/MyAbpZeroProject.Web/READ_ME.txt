﻿Running migrations (specify Password):

Update-Database -ConnectionString "Server=localhost; Database=MyAbpZeroProject; User=sa; Password=;" -ConnectionProviderName "System.Data.SqlClient" -ProjectName "Abp.Samples.Blog.EntityFramework" -Verbose