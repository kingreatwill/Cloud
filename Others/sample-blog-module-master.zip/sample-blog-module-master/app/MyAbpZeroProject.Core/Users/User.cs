﻿using Abp.Authorization.Users;

namespace MyAbpZeroProject.Users
{
    public class User : AbpUser<User>
    {

    }
}