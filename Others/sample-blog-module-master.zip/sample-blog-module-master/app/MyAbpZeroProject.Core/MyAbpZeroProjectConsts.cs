﻿namespace MyAbpZeroProject
{
    public class MyAbpZeroProjectConsts
    {
        public const string LocalizationSourceName = "MyAbpZeroProject";
    }
}