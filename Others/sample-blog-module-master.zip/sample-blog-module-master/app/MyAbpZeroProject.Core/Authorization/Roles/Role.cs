﻿using Abp.Authorization.Roles;
using MyAbpZeroProject.Users;

namespace MyAbpZeroProject.Authorization.Roles
{
    public class Role : AbpRole<User>
    {

    }
}