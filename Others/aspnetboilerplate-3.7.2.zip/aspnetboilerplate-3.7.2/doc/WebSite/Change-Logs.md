See the GitHub repository for all release & change logs:

<https://github.com/aspnetboilerplate/aspnetboilerplate/releases>
