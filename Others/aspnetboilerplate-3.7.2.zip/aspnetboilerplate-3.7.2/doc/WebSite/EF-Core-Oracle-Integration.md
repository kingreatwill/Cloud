Oracle EF Core Database Provider isn't supported officially yet. For more info see:
https://docs.microsoft.com/en-us/ef/core/providers/oracle/

There is a third-party provider; Devart EF Core Database Providers. This is a paid product and there are some [limitations](http://blog.devart.com/entity-framework-core-1-entity-framework-7-support.html#limitations).

When the Oracle EF Core Database Provider is released, a relevant document will be published here.
