﻿namespace Abp.MemoryDb.Configuration
{
    internal class AbpMemoryDbModuleConfiguration : IAbpMemoryDbModuleConfiguration
    {
        //TODO: Configuration...
    }
}