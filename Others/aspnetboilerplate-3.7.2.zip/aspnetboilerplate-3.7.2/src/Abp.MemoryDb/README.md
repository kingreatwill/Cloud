﻿ASP.NET Boilerplate - MemoryDB
------------------------------

MemoryDb implementation for ASP.NET Boilerplate. It's aimed to be used in tests.

IMPORTANT: This project is experimental for now and not tested yet.