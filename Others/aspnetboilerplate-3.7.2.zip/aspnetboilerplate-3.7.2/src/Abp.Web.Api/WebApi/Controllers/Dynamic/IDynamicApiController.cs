namespace Abp.WebApi.Controllers.Dynamic
{
    /// <summary>
    /// This interface is just used to mark dynamic web api controllers.
    /// </summary>
    internal interface IDynamicApiController
    {

    }
}